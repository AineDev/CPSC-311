Please fill out each TODO item in the header.

Please don't reformat the HEADER area of this file, and change nothing
except the TODOs, particularly nothing before the colon ":" on each
line!

We reserve the right to do (minor) point deductions for misformatted
READMEs.

===================== HEADER ========================

Student #1, Name: Aine Kearns
Student #1, students.cs.ubc.ca Login: ainedev
Student #1, Student Number: 45402147

Student #2, Name: Shannon Hogan
Student #2, students.cs.ubc.ca Login: shogan2
Student #2, Student Number: 21707112

Student #3, Name: Kaeli Flanagan
Student #3, students.cs.ubc.ca Login: kaelif
Student #3, Student Number: 41537151

(If you decide to do the assignment as a project group, add ALL the members of the group following this format)

Team name (for fun!): The Terrified Penguins

Acknowledgment that you understand and have followed the course's
collaboration policy (READ IT at
https://www.students.cs.ubc.ca/~cs-311/current/syllabus.html#collaboration-policy-for-assignments):

Signed: Aine Kearns, Kaeli Flanagan, Shannon Hogan

===================== LOGISTICS =====================

Please fill in each of the following:

Acknowledgment of assistance (per the collab policy!): Maja Evans, Lilli Freischmen,  Laura Schmid

For teams, rough breakdown of work: Worked on separately and then combined answers

======================= BONUS =======================

If you attempted any bonuses, please note it here and describe how you
approached them.

N/A

