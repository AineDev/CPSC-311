Please fill out each TODO item in the header.

Please don't reformat the HEADER area of this file, and change nothing
except the TODOs, particularly nothing before the colon ":" on each
line!

We reserve the right to do (minor) point deductions for misformatted
READMEs.

===================== HEADER ========================

Student #1, Name: Aine Kearns
Student #1, students.cs.ubc.ca Login: ainedev
Student #1, Student Number: 45402147

Student #2, Name: TODO (or write "NONE")
Student #2, students.cs.ubc.ca Login: TODO (or write "NONE")
Student #2, Student Number: TODO (or write "NONE")

(If you decide to do the assignment as a project group, add ALL the members of the group following this format)

Team name (for fun!): Terrified Penguins

Acknowledgment that you understand and have followed the course's
collaboration policy (READ IT at
https://www.students.cs.ubc.ca/~cs-311/current/syllabus.html#collaboration-policy-for-assignments):

Signed: Aine Kearns

===================== LOGISTICS =====================

Please fill in each of the following:

Acknowledgment of assistance (per the collab policy!): Maja Evans, Lilli

For teams, rough breakdown of work: TODO (no more than a paragraph
needed!)

======================= BONUS =======================

If you attempted any bonuses, please note it here and describe how you
approached them.

TODO
